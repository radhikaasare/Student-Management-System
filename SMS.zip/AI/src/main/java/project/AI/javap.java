package project.AI;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class javap extends JFrame {

    private JTextField insertField1, insertField2;
    private JTextField deleteField;
    private JTextField updateField1, updateField2;
    private JTextArea outputArea;

    private SessionFactory factory;

    public javap() {
        setTitle("Java Application");
        setSize(700, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

 
        factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Book.class).buildSessionFactory();

        // Creating components
        JLabel labelInsert1 = new JLabel("Insert Field 1 (Username):");
        insertField1 = new JTextField(10);
        JLabel labelInsert2 = new JLabel("Insert Field 2 (Password):");
        insertField2 = new JTextField(10);
        JButton insertButton = new JButton("Insert");

        JLabel labelDelete = new JLabel("Delete Field (Username):");
        deleteField = new JTextField(10);
        JButton deleteButton = new JButton("Delete");

        JLabel labelUpdate1 = new JLabel("Update Field 1 (Username):");
        updateField1 = new JTextField(10);
        JLabel labelUpdate2 = new JLabel("Update Field 2 (Password):");
        updateField2 = new JTextField(10);
        JButton updateButton = new JButton("Update");

        JButton viewButton = new JButton("View");
        outputArea = new JTextArea(10, 30);
        outputArea.setEditable(false);

        // Adding action listeners for buttons
        insertButton.addActionListener(e -> insertData());
        deleteButton.addActionListener(e -> deleteData());
        updateButton.addActionListener(e -> updateData());
        viewButton.addActionListener(e -> viewData());

        // Setting layout
        setLayout(new FlowLayout());

        // Adding components to the frame
        add(labelInsert1);
        add(insertField1);
        add(labelInsert2);
        add(insertField2);
        add(insertButton);
        add(labelDelete);
        add(deleteField);
        add(deleteButton);
        add(labelUpdate1);
        add(updateField1);
        add(labelUpdate2);
        add(updateField2);
        add(updateButton);
        add(viewButton);
        add(new JScrollPane(outputArea));
    }

    private void insertData() {
        String username = insertField1.getText();
        String password = insertField2.getText();

        // Create a new Book object
        Book book = new Book();
        book.setUsername(username);
        book.setPassword(password);

        // Save the object to the database using Hibernate
        try (Session session = factory.getCurrentSession()) {
            session.beginTransaction();
            session.save(book); // Hibernate's save method
            session.getTransaction().commit();
            outputArea.append("Inserted: " + username + ", " + password + "\n");
        } catch (Exception e) {
            e.printStackTrace();
            outputArea.append("Insert Error: " + e.getMessage() + "\n");
        }
    }

    private void deleteData() {
        String username = deleteField.getText();

        try (Session session = factory.getCurrentSession()) {
            session.beginTransaction();


            Book book = session.get(Book.class, username);
            if (book != null) {
                session.delete(book);
                outputArea.append("Deleted: " + username + "\n");
            } else {
                outputArea.append("Book not found for deletion: " + username + "\n");
            }

            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            outputArea.append("Delete Error: " + e.getMessage() + "\n");
        }
    }

    private void updateData() {
        String username = updateField1.getText();
        String newPassword = updateField2.getText();

        try (Session session = factory.getCurrentSession()) {
            session.beginTransaction();

            // Fetch the book by its username and update its password
            Book book = session.get(Book.class, username);
            if (book != null) {
                book.setPassword(newPassword);
                session.update(book);
                outputArea.append("Updated: " + username + " - " + newPassword + "\n");
            } else {
                outputArea.append("Book not found for update: " + username + "\n");
            }

            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            outputArea.append("Update Error: " + e.getMessage() + "\n");
        }
    }

    private void viewData() {
        try (Session session = factory.getCurrentSession()) {
            session.beginTransaction();

            // Use a query to get all books
            List<Book> books = session.createQuery("from Book", Book.class).getResultList();

            outputArea.setText(""); // Clear previous output

            for (Book book : books) {
                outputArea.append("Username: " + book.getUsername() + ", Password: " + book.getPassword() + "\n");
            }

            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            outputArea.append("View Error: " + e.getMessage() + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new javap().setVisible(true));
    }
}
