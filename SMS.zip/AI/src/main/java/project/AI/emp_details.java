package project.AI;


import jakarta.persistence.Embeddable;

@Embeddable
public class emp_details {
	private String email;
	private String departement;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDepartement() {
		return departement;
	}
	public void setDepartement(String departement) {
		this.departement = departement;
	}
	
	
	
	

}
