package project.AI;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class emp {

	
	@Id
	private int ID;
	private String FName;
	private String LName;
	private int EID;
	
	private emp_details edd;
	
	public emp_details getEdd() {
		return edd;
	}
	public void setEdd(emp_details edd) {
		this.edd = edd;
	}
	
	public int getID() {
		return ID;
	}
	public String getFName() {
		return FName;
	}
	public void setFName(String fName) {
		FName = fName;
	}
	public String getLName() {
		return LName;
	}
	public void setLName(String lName) {
		LName = lName;
	}
	public int getEID() {
		return EID;
	}
	public void setEID(int eID) {
		EID = eID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	@Override
	public String toString() {
		return "emp [ID=" + ID + ", FName=" + FName + ", LName=" + LName + ", EID=" + EID + ", edd=" + edd + "]";
	}
	
}

		