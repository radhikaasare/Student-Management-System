package project.AI;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;

@Entity
public class Pcs {
	@Id
    private int Pid;
    private String PcName;

	@ManyToMany
    private List<students> stud = new ArrayList<>();
    private students std;

	public List<students> getStud() {
		return stud;
	}
	public void setStud(List<students> stud) {
		this.stud = stud;
	}
	public students getStd() {
		return std;
	}
	public void setStd(students std) {
		this.std = std;
	}
	public int getPid() {
		return Pid;
	}
	public void setPid(int pid) {
		this.Pid = pid;
	}
	public String getPcName() {
		return PcName;
	}
	public void setPcName(String pcName) {
		this.PcName = pcName;
	}
    	
}
