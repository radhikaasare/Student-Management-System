package project.AI;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;


@Entity
public class students {
	@Id
     private int Roll_no;
     private String SName;
     private int Year;
     @ManyToMany
     private List<Pcs> pcs = new ArrayList<>();
     private students pc;
     
	public students getPc() {
		return pc;
	}
	public void setPc(students pc) {
		this.pc = pc;
	}
	public List<Pcs> getPcs() {
		return pcs;
	}
	public void setPcs(List<Pcs> pcs) {
		this.pcs = pcs;
	}
	public int getRoll_no() {
		return Roll_no;
	}
	public void setRoll_no(int roll_no) {
		this.Roll_no = roll_no;
	}
	public String getSName() {
		return SName;
	}
	public void setSName(String sName) {
		this.SName = sName;
	}
	public int getYear() {
		return Year;
	}
	public void setYear(int year) {
		this.Year = year;
	}
     
     
}
