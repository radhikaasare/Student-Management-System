//package project.AI;
//
//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.hibernate.Transaction;
//import org.hibernate.cfg.Configuration;
//
//
//public class App 
//{
//    public static void main( String[] args )
//    {
//    	
//        students st = new students();
//        st.setRoll_no(105);
//        st.setSName("Dodo");
//        st.setYear(4);
//        
//        Pcs pc = new Pcs();
//        pc.setPid(213);
//        pc.setPcName("Asus");
//        pc.setStd(st);
//        
//        st.getPcs().add(pc);
//        
//        Pcs pc1 = new Pcs();
//        pc1.setPid(214);
//        pc1.setPcName("Dell");
//        pc1.setStd(st);
//        
//        st.getPcs().add(pc1);
//        
//        students st1 = new students();
//        st1.setRoll_no(106);
//        st1.setSName("Poko");
//        st1.setYear(4);
//        
//        Pcs p = new Pcs();
//        p.setPid(217);
//        p.setPcName("Apple");
//        p.setStd(st1);
//        
// 
//        st1.getPcs().add(p);
//        
////        pc.getStud().add(st1);
////        p.getStud().add(st1);
//        
//        Configuration con = new Configuration().configure().addAnnotatedClass(students.class).addAnnotatedClass(Pcs.class);
//        SessionFactory sf=con.buildSessionFactory();
//        Session s= sf.openSession();
//        Transaction tx = s.beginTransaction();
//        s.save(st);
//        s.save(st1);
//    	s.save(pc);
//    	s.save(pc1);
//    	s.save(p);
//    	tx.commit();
//    }
//}

