package project1.AI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class MainGUI {

    public static void main(String[] args) {
        // Create the main window
        JFrame mainFrame = new JFrame("Student Management System");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(400, 200);
        mainFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JButton loginButton = new JButton("Login");
        JButton registrationButton = new JButton("Registration");

        gbc.gridx = 0;
        gbc.gridy = 0;
        mainFrame.add(loginButton, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        mainFrame.add(registrationButton, gbc);

        loginButton.addActionListener(e -> openLoginGUI());
        registrationButton.addActionListener(e -> openRegistrationGUI());

        mainFrame.setVisible(true);
    }

    // Registration GUI method
    private static void openRegistrationGUI() {
        JFrame regFrame = new JFrame("Registration");
        regFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        regFrame.setSize(600, 600);
        regFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // Create form components
        JLabel firstNameLabel = new JLabel("First Name:");
        JTextField firstNameField = new JTextField(15);
        JLabel lastNameLabel = new JLabel("Last Name:");
        JTextField lastNameField = new JTextField(15);
        JLabel rollNoLabel = new JLabel("Roll No:");
        JTextField rollNoField = new JTextField(15);
        JLabel branchLabel = new JLabel("Branch:");
        JTextField branchField = new JTextField(15);
        JLabel yearLabel = new JLabel("Year:");
        JTextField yearField = new JTextField(15);
        JLabel semesterLabel = new JLabel("Semester:");
        JTextField semesterField = new JTextField(15);
        JLabel contactLabel = new JLabel("Contact:");
        JTextField contactField = new JTextField(15);
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(15);
        JLabel genderLabel = new JLabel("Gender:");
        JComboBox<String> genderCombo = new JComboBox<>(new String[]{"Please Select", "Male", "Female", "Other"});
        JLabel addressLabel = new JLabel("Address:");
        JTextField addressField = new JTextField(15);
        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField(15);
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(15);
        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        JPasswordField confirmPasswordField = new JPasswordField(15);

        JButton registerButton = new JButton("Submit");

        // Add components to the form using GridBagLayout
        gbc.gridx = 0;
        gbc.gridy = 0;
        regFrame.add(firstNameLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(firstNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        regFrame.add(lastNameLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(lastNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        regFrame.add(rollNoLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(rollNoField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        regFrame.add(branchLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(branchField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        regFrame.add(yearLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(yearField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        regFrame.add(semesterLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(semesterField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        regFrame.add(contactLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(contactField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        regFrame.add(emailLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 8;
        regFrame.add(genderLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(genderCombo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 9;
        regFrame.add(addressLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(addressField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 10;
        regFrame.add(usernameLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 11;
        regFrame.add(passwordLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 12;
        regFrame.add(confirmPasswordLabel, gbc);
        gbc.gridx = 1;
        regFrame.add(confirmPasswordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 13;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        regFrame.add(registerButton, gbc);

        // Action listener for the register button
        registerButton.addActionListener(e -> {
            if (!new String(passwordField.getPassword()).equals(new String(confirmPasswordField.getPassword()))) {
                JOptionPane.showMessageDialog(null, "Passwords do not match!");
                return;
            }

            Student student = new Student();
            student.setfName(firstNameField.getText());
            student.setlName(lastNameField.getText());
            student.setRollNo(Integer.parseInt(rollNoField.getText()));
            student.setBranch(branchField.getText());
            student.setYear(Integer.parseInt(yearField.getText()));
            student.setSem(Integer.parseInt(semesterField.getText()));
            student.setContact(contactField.getText());
            student.setEmail(emailField.getText());
            student.setGender((String) genderCombo.getSelectedItem());
            student.setAddress(addressField.getText());
            student.setUsername(usernameField.getText());
            student.setPassword(new String(passwordField.getPassword()));

            saveStudentToDB(student);
        });

        regFrame.setVisible(true);
    }


    // Login GUI method
 // Login GUI method
    private static void openLoginGUI() {
        JFrame loginFrame = new JFrame("Login");
        loginFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        loginFrame.setSize(400, 200);
        loginFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField(15);
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(15);
        JButton loginButton = new JButton("Login");

        gbc.gridx = 0;
        gbc.gridy = 0;
        loginFrame.add(usernameLabel, gbc);

        gbc.gridx = 1;
        loginFrame.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        loginFrame.add(passwordLabel, gbc);

        gbc.gridx = 1;
        loginFrame.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        loginFrame.add(loginButton, gbc);

        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            Student student = authenticateAndGetUser(username, password);
            if (student != null) {
                JOptionPane.showMessageDialog(null, "Login successful!");
                showStudentInfo(student); // Display the student info GUI
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password.");
            }
        });

        loginFrame.setVisible(true);
    }

    // Method to authenticate user and fetch user data
    private static Student authenticateAndGetUser(String username, String password) {
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Student.class)
                .buildSessionFactory();

        Session session = factory.openSession();
        Student student = null;

        try {
            session.beginTransaction();
            student = session.createQuery("FROM Student WHERE username = :username AND password = :password", Student.class)
                    .setParameter("username", username)
                    .setParameter("password", password)
                    .uniqueResult();
            session.getTransaction().commit();
        } catch (Exception e) {
            if (session.getTransaction() != null) {
                session.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
            factory.close();
        }

        return student; // Return the student object if authenticated, otherwise null
    }

    // Method to show student information
    private static void showStudentInfo(Student student) {
        JFrame infoFrame = new JFrame("Student Information");
        infoFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        infoFrame.setSize(400, 400);
        infoFrame.setLayout(new GridLayout(0, 1)); // Use GridLayout to display fields in a single column

        // Display all the student's information
        infoFrame.add(new JLabel("First Name: " + student.getfName()));
        infoFrame.add(new JLabel("Last Name: " + student.getlName()));
        infoFrame.add(new JLabel("Roll No: " + student.getRollNo()));
        infoFrame.add(new JLabel("Branch: " + student.getBranch()));
        infoFrame.add(new JLabel("Year: " + student.getYear()));
        infoFrame.add(new JLabel("Semester: " + student.getSem()));
        infoFrame.add(new JLabel("Contact: " + student.getContact()));
        infoFrame.add(new JLabel("Email: " + student.getEmail()));
        infoFrame.add(new JLabel("Gender: " + student.getGender()));
        infoFrame.add(new JLabel("Address: " + student.getAddress()));
        infoFrame.add(new JLabel("Username: " + student.getUsername()));

        infoFrame.setVisible(true);
    }


    // Method to save student to the database
    private static void saveStudentToDB(Student student) {
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Student.class)
                .buildSessionFactory();

        Session session = factory.openSession();
        try {
            session.beginTransaction();
            session.save(student);
            session.getTransaction().commit();
            JOptionPane.showMessageDialog(null, "Registration successful!");
        } catch (Exception e) {
            if (session.getTransaction() != null) {
                session.getTransaction().rollback();
            }
            JOptionPane.showMessageDialog(null, "Error during registration. Please try again.");
            e.printStackTrace();
        } finally {
            session.close();
            factory.close();
        }
    }

    // Method to authenticate user
    private static boolean authenticateUser(String username, String password) {
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Student.class)
                .buildSessionFactory();

        Session session = factory.openSession();
        boolean isAuthenticated = false;

        try {
            session.beginTransaction();
            Student student = session.createQuery("FROM Student WHERE username = :username AND password = :password", Student.class)
                    .setParameter("username", username)
                    .setParameter("password", password)
                    .uniqueResult();
            isAuthenticated = (student != null);
            session.getTransaction().commit();
        } catch (Exception e) {
            if (session.getTransaction() != null) {
                session.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
            factory.close();
        }

        return isAuthenticated;
    }
}
